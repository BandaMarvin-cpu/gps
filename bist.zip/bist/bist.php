<?php
$servername = "localhost";
$username = "root";
$password = "5Np29+l8n4Xw";
$dbname = "tv_management_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_tv'])) {
        $tvIdToDelete = $_POST['delete_tv'];
        $sqlDelete = "DELETE FROM tv_details WHERE id = '$tvIdToDelete'";
        if ($conn->query($sqlDelete) === TRUE) {
            echo "TV record with ID $tvIdToDelete deleted successfully!";
        } else {
            echo "Error deleting TV record: " . $conn->error;
        }
    } else {
        $brand = $_POST['brand'];
        $date = $_POST['date'];
        $model = $_POST['model'];
        $size = $_POST['size'];
        $latitude = $_POST['latitude'];
        $longitude = $_POST['longitude'];

        $sql = "INSERT INTO tv_details (brand, date, model, size, latitude, longitude) VALUES ('$brand','$date', '$model', '$size', '$latitude', '$longitude')";

        if ($conn->query($sql) === TRUE) {
            echo "TV details saved successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>TV Trucking Platform</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            background-color: #5c94e3;
            color: #fff;
            padding: 20px;
            margin: 0;
        }

        .dashboard {
            width: 25%;
            float: left;
            padding: 20px;
            background-color: #f5f5f5;
            box-sizing: border-box;
        }

        .dashboard h2 {
            margin-top: 0;
            font-size: 24px;
            margin-bottom: 15px;
        }

        .dashboard label {
            display: block;
            font-weight: bold;
        }

        .dashboard input[type="text"],
        .dashboard input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .dashboard button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #5c94e3;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        #map-container {
            width: 75%;
            margin-left: 25%; /* Place the map container next to the dashboard */
            height: 400px;
        }

        #map {
            height: 100%; /* Make the map fill the map container */
            width: 100%;
        }

        #tv-details-section {
            width: 100%;
            display: none;
        }

        #tv-details-section h2 {
            font-size: 20px;
            margin-top: 0;
            margin-bottom: 15px;
        }

        #tv-details-section table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ccc;
        }

        #tv-details-section th,
        #tv-details-section td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }

        #tv-details-section th {
            background-color: #5c94e3;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>TV Trucking Platform</h1>

    <div class="dashboard">
        <h2>TV Management</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <label for="brand">Brand:</label>
            <input type="text" id="brand" name="brand" required><br>

            <label for="date">datetime:</label>
            <input type="date" id="date" name="date" required><br>

            <label for="model">Model:</label>
            <input type="text" id="model" name="model" required><br>

            <label for="size">Size:</label>
            <input type="number" id="size" name="size" required><br>

            <!-- Add inputs to capture latitude and longitude -->
            <label for="latitude">Latitude:</label>
            <input type="text" id="latitude" name="latitude" required><br>

            <label for="longitude">Longitude:</label>
            <input type="text" id="longitude" name="longitude" required><br>

            <button type="submit">Add TV</button>
        </form>

        <button onclick="showAllTVDetails()">Show All TV Details</button>

        <!-- Add the button to toggle satellite view -->
        <button onclick="toggleSatelliteView()">Toggle Satellite View</button>
    </div>

    <div id="map-container">
        <div id="map"></div>
    </div>

    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />

    <script>
        const map = L.map('map').setView([37.7749, -122.4194], 8);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Initialize the satellite layer (Hidden by default)
        const satelliteLayer = L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
        });

        // Function to toggle satellite view
        function toggleSatelliteView() {
            if (map.hasLayer(satelliteLayer)) {
                map.removeLayer(satelliteLayer);
            } else {
                map.addLayer(satelliteLayer);
            }
        }

        function goToLocation(latitude, longitude) {
            map.setView([latitude, longitude], 10);
        }

        function showAllTVDetails() {
            const tvDetailsSection = document.getElementById('tv-details-section');
            tvDetailsSection.style.display = 'block';
        }
    </script>

    <div id="tv-details-section" style="display: none;">
        <h2>All TV Details</h2>
        <?php
            $sql = "SELECT * FROM tv_details";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table border='1'>";
                echo "<tr><th>ID</th><th>Brand</th><th>Model</th><th>Size</th><th>Latitude</th><th>Longitude</th><th>Action</th></tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['brand'] . "</td>";
                    echo "<td>" . $row['date'] . "</td>";
                    echo "<td>" . $row['model'] . "</td>";
                    echo "<td>" . $row['size'] . "</td>";
                    echo "<td>" . $row['latitude'] . "</td>";
                    echo "<td>" . $row['longitude'] . "</td>";
                    // Add locate and delete buttons
                    echo "<td>";
                    echo "<button onclick=\"goToLocation(" . $row['latitude'] . ", " . $row['longitude'] . ")\">Locate</button>";
                    echo "<form action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "' method='POST' style='display: inline-block; margin-left: 5px;'>";
                    echo "<button type='submit' name='delete_tv' value='" . $row['id'] . "'>Delete</button>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No TV details found.";
            }

            $result->close();
        ?>
    </div>
</body>
</html>
